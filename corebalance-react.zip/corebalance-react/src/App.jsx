
import React from 'react'

function App() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-blue-900 text-white py-10 text-center">
        <h1 className="text-4xl font-bold">CoreBalance Technology Management</h1>
        <p className="mt-2">Empowering SMEs in Qatar with Digital Excellence</p>
      </header>
      <main className="p-6">
        <section id="about" className="my-6">
          <h2 className="text-2xl font-bold mb-2">About Us</h2>
          <p>We provide bilingual software training, POS setup, and digital consultancy services in Qatar.</p>
        </section>
        <section id="services" className="my-6">
          <h2 className="text-2xl font-bold mb-2">Our Services</h2>
          <ul className="list-disc ml-6">
            <li>POS & Accounting Software Setup</li>
            <li>Zoho, Excel, ERPNext, Tally Training</li>
            <li>Cloud & Website Deployment</li>
          </ul>
        </section>
        <section id="contact" className="my-6">
          <h2 className="text-2xl font-bold mb-2">Contact Us</h2>
          <p>WhatsApp: <a href="https://wa.me/974XXXXXXXXX" className="text-green-600 underline">Chat Now</a></p>
        </section>
      </main>
      <footer className="bg-gray-100 text-center py-4">
        <p>&copy; 2025 CoreBalance Technology Management</p>
      </footer>
    </div>
  )
}

export default App
